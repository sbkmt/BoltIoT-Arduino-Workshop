/* Provided by Inventrom for interfacing Bolt to Arduino */

/* 
 * File:   BoltDeviceCredentials.h
 * Author: Inventrom
 *
 * Created on 12 July, 2021, 4:00 PM
 */

#ifndef BOLD_DEVICECREDENTIALS_H
#define BOLD_DEVICECREDENTIALS_H

/*
* Uncomment the following, and re-place the corresponding credentials.
* Be careful, these will overwrite all credentials in the example files.
*/
//#define API_KEY   "xxxxxxx-xxxx-xxxx-xxxx-xxxxxxxx"
//#define DEVICE_ID "BOLTxxxxxxxx"


#endif